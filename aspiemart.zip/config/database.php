<?php
date_default_timezone_set('Asia/Jakarta');

session_start();

$DB_HOST = 'localhost';
$DB_NAME = 'mart-aspi';
$DB_USER = 'root';
$DB_PASS = '';

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
        $pdo->exec("SET time_zone = '+07:00'");

} catch (PDOException $e) {
    die('Koneksi database gagal: ' . $e->getMessage());
}

require_once __DIR__ . '/../includes/functions.php';